# Kitchen Order Management v3

Includes:
- Waiter portal, Kitchen portal, Admin portal
- Socket.IO real-time updates
- Add items to existing table
- Distinct sounds
- Clean minimal UI
- Ready for Railway deployment

Place public WAV files in /public:
- sounds_new_order.wav
- sounds_add_items.wav
- sounds_billing_request.wav
