
const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const path = require('path');
const app = express();
const server = http.createServer(app);
const io = new Server(server);

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// In-memory data for demo
let items = [{id:1,name:"Veg Ramen",price:150},{id:2,name:"Paneer Pizza",price:200}];
let orders = [];
let orderIdCounter = 1;

// API endpoints
app.get('/api/items',(req,res)=>res.json(items));
app.post('/api/orders',(req,res)=>{
    const {table_no, items: orderItems, special_requests} = req.body;
    const order = {id:orderIdCounter++, table_no, items:orderItems, special_requests, status:'placed'};
    orders.push(order);
    io.emit('order:placed', order);
    res.json({ok:true, id:order.id});
});
app.post('/api/orders/:table/add-items',(req,res)=>{
    const table = req.params.table;
    const {items: newItems, special_requests} = req.body;
    const order = orders.find(o=>o.table_no===table && o.status!=='billed');
    if(order){
        order.items.push(...newItems);
        if(special_requests) order.special_requests += "; " + special_requests;
        io.emit('order:items-added', order);
        res.json({ok:true});
    } else { res.json({ok:false,error:"Table not found"}); }
});
app.post('/api/orders/:id/status',(req,res)=>{
    const id = parseInt(req.params.id);
    const {status} = req.body;
    const order = orders.find(o=>o.id===id);
    if(order){ order.status = status; io.emit('order:status-changed', order); res.json({ok:true}); }
    else res.json({ok:false,error:"Order not found"});
});
app.post('/api/orders/:id/bill',(req,res)=>{
    const id = parseInt(req.params.id);
    const idx = orders.findIndex(o=>o.id===id);
    if(idx>=0){ const order = orders.splice(idx,1)[0]; io.emit('order:billed', order); res.json({ok:true}); }
    else res.json({ok:false,error:"Order not found"});
});

const PORT = process.env.PORT || 3000;
server.listen(PORT,()=>console.log("KDS server running on port",PORT));
